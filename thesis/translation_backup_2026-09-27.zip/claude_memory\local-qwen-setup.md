---
name: local-qwen-setup
description: "Local Qwen3.8-27B via llama.cpp in C:\\AI — hardware limits, measured speeds, VRAM-contention pitfall, /qwen skill"
metadata:
  node_type: memory
  type: project
  originSessionId: 64eb416b-86dd-429e-9275-ae5a66fb5732
  modified: 2026-09-26T17:51:06.688Z
---

Local LLM: `C:\AI` (llama.cpp + Qwen3.8-27B Q4_K_XL), server http://127.0.0.1:8080, launched by `C:\AI\start-qwen.ps1`.
PC since 2026-09-26: i7-12700F, RTX 3060 12 GB, 32 GB DDR4-2400 (4×8). Default profile 32k ctx + vision.
Measured: prompt ~230 tok/s, generation ~6–7 tok/s (MTP on), image ~2 min/page.

**Why:** the bottleneck is VRAM, not RAM — longer context moves layers off the GPU. Other apps holding VRAM
(browser etc.) dropped prompt speed to 16–23 tok/s (10× slower); closing them fixed it.

**How to apply:** if Qwen is unexpectedly slow, ask the user to close GPU apps before tuning flags.
Offloading work to it goes through the /qwen skill (`~\.claude\skills\qwen\qwen-run.py`, ledger next to it).
Related: [[agy-skills]]
