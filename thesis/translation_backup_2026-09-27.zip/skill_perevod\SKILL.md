---
name: perevod
description: Translate the PhD dissertation (C:\VirtualD\dissertation\thesis) between English, Russian and Kazakh with the local Qwen, using the translation kit in thesis/translation (rules, trilingual termbase, translation memory, automatic checks). Use when the user says /perevod, «переведи главу/раздел диссертации», «аударма», "translate the thesis/section", or asks for a RU/KZ/EN version of a dissertation file; also to improve the kit when a translation error is found.
---

# /perevod — dissertation translation EN ↔ RU ↔ KZ by the local Qwen

Kit: `C:\VirtualD\dissertation\thesis\translation\` (README.md there has the details).
Qwen does the translating; I pick the files, launch, accept through the checks and fix the kit when it errs.

## Run
```bash
cd C:/VirtualD/dissertation/thesis/translation
python translate.py --tgt ru chapters/04-system/drafts/4.4-draft.md          # one section EN->RU
python translate.py --tgt ru "chapters/*/drafts/*-draft.md"                   # whole volume (hours; resumable)
python translate.py --src kz --tgt ru chapters/03-experiments/translations/3.4-translation.md   # KZ->RU, EN used as pivot
python translate.py --tgt en --out <dir> <any .md file>                        # RU/KZ -> EN, any file
```
Council / official documents (genre `council`: official-administrative style, rules/genre-council.md,
council terms, council examples; the default for any non-chapter file). Only the body text is translated -
title blocks, headings, running heads, tables/forms and signature lines are dropped by extract_body.py:
```bash
python extract_body.py "C:/VirtualD/council/<doc>.docx" <scratch>/doc.body.md    # .docx or pdftotext .txt
python translate.py --src ru --tgt kz --genre council --out <dir> <scratch>/doc.body.md
```
Output of chapter files: `chapters/<ch>/translations-<tgt>/<id>-<tgt>.md` (+ `.report.json`, `.parts/` cache).
The approved Kazakh edition in `translations/` is never written to.
Timing: ~4–6 min per ~450-word chunk (generation ~7 tok/s); a section = 2–8 chunks. Anything > 1 section →
`run_in_background: true`, one run at a time (one server slot). Ask the user to close GPU-heavy apps first
(`WARN: prompt speed < 100 t/s` in the log = VRAM contention).

## Accept
1. Summary line per file: `NEEDS_REVIEW [chunks]` — only those chunks need my reading; the report lists the errors.
2. `python check.py <source> <translation>` re-checks a whole file after manual edits.
3. Spot-read 1–2 clean chunks per chapter for meaning (hedges, negations, numbers in context).
4. `python eval.py --set council --tag <name>` measures the council genre: 8 held-out items, 6 directions,
   chrF++ vs the human text and chrF_gold vs Opus's corrected reference (`work/gold/`, the main number).
   `python eval.py --tag <name>` measures quality (chrF++ against held-out approved translations);
   `python eval.py --compare` shows all runs. Baseline and targets: README.md.

## The learning loop (how Qwen "learns")
Qwen is not fine-tuned; it learns through the context the kit builds. When a translation error is found:
- wrong/unstable term → add or fix a row in `termbase.tsv` (EN, RU, KZ, rule, note, domain: empty=all | thesis | council);
- repeated style/grammar error → one short, concrete line in `rules/<lang>.md` (or `rules/common.md`,
  or `rules/genre-council.md` for official documents), with a wrong → right example;
- after any rule change for one genre, rerun the other genre's eval too (regression).
- error the checker could have caught → add a pattern to `check.py` (FORBIDDEN / SOFT);
- then delete the affected `.parts/*.json` cache entries (or the whole `.parts/`) and rerun those files.
Keep rules short: they are read by a 27B model on every chunk — each line costs prompt time.
