---
name: thesis-translation-kit
description: "Qwen translation kit for the PhD thesis EN/RU/KZ in C:\\VirtualD\\dissertation\\thesis\\translation (D: drive retired 2026-09-27), /perevod skill, measured quality"
metadata:
  node_type: memory
  type: project
  originSessionId: d63a328b-ab60-4c13-96ff-ab053c3909d0
  modified: 2026-09-27T10:35:13.857Z
---

Built 2026-09-27: `C:\VirtualD\dissertation\thesis\translation\` (rules/, termbase.tsv, tm/, translate.py,
check.py, eval.py) + skill `~\.claude\skills\perevod`. Qwen is taught in-context (no fine-tune on 12 GB).
Measured it1: EN→KZ chrF++ 70.2 vs approved KZ on held-out 3.4/4.2/1.3 (unrelated-section floor 30),
EN→RU 66.4 vs abstract_ru. ~4 min per 450-word chunk; whole volume = 121 chunks.

Iteration 2 (2026-09-27): genre `council` for dissertation-council documents (GD_01 guide, abstracts):
rules/genre-council.md, termbase 6th column domain (all|thesis|council), rules/postfix-kz.tsv (deterministic fixes),
extract_body.py (body text only, no headers/headings/forms/signatures - user's requirement), eval --set council /
council-valid, Opus gold refs in work/gold, work/probes.py (28 c0 errors -> 0-1 fire). Council chrF_gold 82.1 -> ~84.
Thesis-domain terms can poison other genres (thesis row Transformer->KZ "vision transformer" caused invented text):
mark domain-specific rows `thesis`.

**Why:** GLOSSARY_KZ.md is stale (keeps "pipeline" Latin); the approved chapter translations and
conformance.py (short dash « – », т.б., «, сондықтан» ≤12) are the real authority — termbase KZ forms
were taken from the translations.

**How to apply:** fix translation errors by editing termbase.tsv / rules/<lang>.md, then delete the
`.parts/` cache of affected files and rerun. RU outputs go to chapters/*/translations-ru/.
Related: [[local-qwen-setup]]
