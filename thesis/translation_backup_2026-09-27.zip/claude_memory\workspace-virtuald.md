---
name: workspace-virtuald
description: PhD projects moved from external drive D:\personal\phd to C:\VirtualD (D: being disconnected) — use C:\VirtualD paths
metadata:
  type: project
---

2026-09-27 the user copied `D:\personal\phd\dissertation` → `C:\VirtualD\dissertation` and
`D:\personal\phd\council` → `C:\VirtualD\council`; the external D: drive is being disconnected.

**Why:** D: will not be available; old paths in notes/scripts will fail.
**How to apply:** always work in C:\VirtualD. The copy lacks: thesis/scripts/ (conformance.py,
kk_style_check.py), the dissertation `.git`, meeting videos and onnx models under council — ask the user
before relying on them. Related: [[thesis-translation-kit]]
